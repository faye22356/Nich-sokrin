/**
 * ALL EDITABLE WEDDING CONTENT LIVES HERE.
 * Edit the text between the quotation marks. Keep the commas, brackets and quotes.
 * Khmer names are copied exactly as supplied - do not auto-translate them.
 */
export const wedding = {
  couple: {
    groom: { khmer: "ផេង ផាសុករិន្ទរ៍", english: "Pheng Phasokrin" },
    bride: { khmer: "សែម សុម៉ានិច", english: "Sem Somanich" },
    monogram: ["ស", "ម"],
  },

  families: {
    groom: {
      parents: [
        { khmer: "ផេង ផានី", english: "Pheng Phany" },
        { khmer: "ប៊ូ ស៊ីនដា", english: "Bou Sinda" },
      ],
    },
    bride: {
      parents: [
        { khmer: "គង់ សំអឿន", english: "Kong Samourn" },
        { khmer: "ទួន សុភា", english: "Tourn Sophea" },
      ],
    },
  },

  date: {
    // 08:00 Phnom Penh time (UTC+7, no daylight saving). Used by the countdown.
    startIso: "2027-03-07T08:00:00+07:00",
    // Countdown shows "today is the day" until this moment, then the thank-you message.
    endIso: "2027-03-07T23:59:59+07:00",
    timeZone: "Asia/Phnom_Penh",
    english: "Sunday, 7 March 2027",
    khmer: "ថ្ងៃអាទិត្យ ទី៧ ខែមីនា ឆ្នាំ២០២៧",
    // Supplied by the couple. NOT yet verified against a Cambodian calendar - see PRIVATE_CHECKLIST.md.
    khmerLunar: "ថ្ងៃអាទិត្យ ១៤ រោច ខែផល្គុន ឆ្នាំមមី អដ្ឋស័ក ព.ស. ២៥៧០",
    khmerLunarVerified: false,
  },

  invitation: {
    heading: { khmer: "សេចក្តីអញ្ជើញ", english: "You are invited" },
    khmer: [
      "ក្រុមគ្រួសារទាំងសងខាង សូមគោរពអញ្ជើញ លោក លោកស្រី អ្នកនាង កញ្ញា ចូលរួមជាភ្ញៀវកិត្តិយស ក្នុងពិធីអាពាហ៍ពិពាហ៍របស់កូនទាំងពីរ។",
      "វត្តមាន និងពរជ័យរបស់លោកអ្នកទាំងអស់ នឹងធ្វើឱ្យពិធីនេះកាន់តែមានអត្ថន័យ។",
    ],
    english: [
      "Together with their families, Pheng Phasokrin and Sem Somanich warmly invite you to celebrate their wedding.",
      "Your presence and blessings will make the day truly meaningful.",
    ],
  },

  /**
   * CEREMONY PROGRAMME - Khmer only, exactly as supplied. Do not add English.
   * needsFamilyConfirmation is internal (never shown to guests); see PRIVATE_CHECKLIST.md.
   */
  programme: [
    { time: "08:00 – 09:00", khmer: "ភ្ញៀវអញ្ជើញមកដល់ និងទទួលទានអាហារសម្រន់" },
    { time: "09:00 – 09:20", khmer: "ពិធីពិសាស្លាដក់កន្សែង" },
    { time: "09:20 – 09:45", khmer: "ពិធីពិសាស្លាចាស់ទុំ" },
    { time: "09:45 – 10:00", khmer: "ពិធីបំពាក់ចិញ្ចៀន" },
    { time: "10:00 – 10:40", khmer: "ពិធីសែនគួចចងដៃ", needsFamilyConfirmation: true },
    { time: "10:40 – 11:00", khmer: "ថតរូបអនុស្សាវរីយ៍ជាមួយក្រុមគ្រួសារ" },
    { time: "11:00", khmer: "ពិសាអាហារថ្ងៃត្រង់" },
  ],

  venue: {
    khmer: "ភោជនីយដ្ឋានមាលា",
    english: "Mealea Restaurant",
    address: "No. 44 Sothearos Boulevard and Street 240, Phnom Penh 12206, Cambodia",
    buttonLabel: "មើលទីតាំង",
    buttonLabelEnglish: "View location",
    /**
     * No exact Google Maps pin was supplied. This link searches Google Maps for the venue by name and
     * address. Replace it with the venue's own "Share > Copy link" URL once you have confirmed the pin.
     */
    mapUrl:
      "https://www.google.com/maps/search/?api=1&query=" +
      encodeURIComponent("Mealea Restaurant, No. 44 Sothearos Boulevard, Phnom Penh 12206, Cambodia"),
    mapPinVerified: false,
  },

  music: {
    // Path to an audio file you may legally use, e.g. "/audio/song.mp3" (file goes in public/audio/).
    // Leave "" to hide the music player. A YouTube/Spotify page link will NOT work here.
    src: "",
    title: "",
    artist: "",
    // Where the original song comes from / who has permitted it (for your own notes):
    sourceNote: "",
  },

  // Real photos: put files in public/gallery/ and list them, e.g. { src: "/gallery/01.jpg", alt: "Phasokrin and Somanich" }
  // While this list is empty, neutral placeholder frames are shown.
  gallery: [] as { src: string; alt: string }[],

  rsvp: {
    maxGuests: 6,
  },

  closing: {
    khmer: "សូមអរគុណយ៉ាងជ្រាលជ្រៅចំពោះវត្តមាន និងពរជ័យពីក្រុមគ្រួសារ ញាតិមិត្ត និងភ្ញៀវកិត្តិយសទាំងអស់។",
    english: "Thank you for sharing this day with us. Your presence and blessings mean the world to our families.",
  },
};
