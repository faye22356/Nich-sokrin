import Shell from "@/components/Shell";
import Invitation from "@/components/Invitation";
import Family from "@/components/Family";
import Countdown from "@/components/Countdown";
import Programme from "@/components/Programme";
import Venue from "@/components/Venue";
import Gallery from "@/components/Gallery";
import Rsvp from "@/components/Rsvp";
import Closing from "@/components/Closing";

export default function Page() {
  // Read on the server only; the secret URL is never sent to the browser, just this yes/no.
  const rsvpConfigured = Boolean(process.env.RSVP_WEBHOOK_URL);
  return (
    <Shell>
      <main className="pb-16">
        <Invitation />
        <Family />
        <Countdown />
        <Programme />
        <Venue />
        <Gallery />
        <Rsvp configured={rsvpConfigured} />
        <Closing />
      </main>
    </Shell>
  );
}
