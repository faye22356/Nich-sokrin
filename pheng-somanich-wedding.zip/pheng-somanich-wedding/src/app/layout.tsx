import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Moul, Noto_Serif_Khmer } from "next/font/google";
import "./globals.css";

const latin = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  variable: "--font-latin",
  display: "swap",
});
const khmer = Noto_Serif_Khmer({
  subsets: ["khmer"],
  weight: ["400", "500", "700"],
  variable: "--font-khmer",
  display: "swap",
});
const moul = Moul({ subsets: ["khmer"], weight: "400", variable: "--font-moul", display: "swap" });

const title = "Pheng Phasokrin & Sem Somanich · Wedding Invitation · 7 March 2027";
const description =
  "You are invited to the wedding of Pheng Phasokrin and Sem Somanich on Sunday, 7 March 2027 at Mealea Restaurant, Phnom Penh.";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title,
  description,
  // Guests-only invitation: asks search engines not to list it. Remove this line to allow indexing.
  robots: { index: false, follow: false },
  openGraph: { title, description, type: "website", locale: "en_US" },
  twitter: { card: "summary", title, description },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#5A0F22",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="km" className={`${latin.variable} ${khmer.variable} ${moul.variable}`}>
      <body className="font-body text-wine antialiased">
        <noscript>
          <style>{`.reveal{opacity:1!important;transform:none!important}`}</style>
        </noscript>
        {children}
      </body>
    </html>
  );
}
