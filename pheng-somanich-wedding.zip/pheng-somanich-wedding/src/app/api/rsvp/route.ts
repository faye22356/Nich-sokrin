import { NextResponse } from "next/server";
import { wedding } from "@/config/wedding";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const url = process.env.RSVP_WEBHOOK_URL;
  if (!url) return NextResponse.json({ ok: false, error: "not_configured" }, { status: 503 });

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "bad_request" }, { status: 400 });
  }

  // Hidden "website" field is a trap for bots; real guests leave it empty.
  if (body.website) return NextResponse.json({ ok: true });

  const name = String(body.name ?? "").trim().slice(0, 100);
  const attending = body.attending === "yes" ? "yes" : body.attending === "no" ? "no" : "";
  if (!name || !attending) return NextResponse.json({ ok: false, error: "invalid" }, { status: 400 });

  const guests =
    attending === "yes"
      ? Math.min(Math.max(parseInt(String(body.guests), 10) || 1, 1), wedding.rsvp.maxGuests)
      : 0;
  const message = String(body.message ?? "").trim().slice(0, 500);

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ name, attending, guests, message, submittedAt: new Date().toISOString() }),
    });
    if (!res.ok) return NextResponse.json({ ok: false, error: "upstream" }, { status: 502 });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: false, error: "upstream" }, { status: 502 });
  }
}
