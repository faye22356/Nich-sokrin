import { wedding } from "@/config/wedding";
import Section, { Divider } from "./Section";

export default function Closing() {
  const { closing, couple, date } = wedding;
  return (
    <Section id="closing">
      <Divider />
      <p className="km mx-auto max-w-md text-base sm:text-lg">{closing.khmer}</p>
      <p className="mx-auto mt-4 max-w-md font-latin text-lg italic leading-relaxed sm:text-xl">{closing.english}</p>
      <div className="mt-10">
        <p className="font-display km-title text-lg text-burgundy">
          {couple.groom.khmer} <span className="text-gold">&amp;</span> {couple.bride.khmer}
        </p>
        <p className="font-latin text-xl text-gold">
          {couple.groom.english} &amp; {couple.bride.english}
        </p>
        <p className="mt-1 font-latin text-base text-wine/70">{date.english}</p>
      </div>
      <Divider />
    </Section>
  );
}
