import Reveal from "./Reveal";

const tones = {
  ivory: "text-wine",
  blush: "bg-blush/40 text-wine",
  wine: "bg-burgundy text-ivory",
} as const;

export function Divider({ light = false }: { light?: boolean }) {
  const c = light ? "#E6D0A1" : "#B8893A";
  return (
    <svg aria-hidden="true" viewBox="0 0 220 24" className="mx-auto my-5 h-6 w-56">
      <path d="M0 12H86M134 12H220" stroke={c} strokeWidth="1" />
      <path d="M110 3l7 9-7 9-7-9z" fill="none" stroke={c} strokeWidth="1.2" />
      <path d="M92 12c5-7 10-7 12 0M128 12c-5-7-10-7-12 0M92 12c5 7 10 7 12 0M128 12c-5 7-10 7-12 0" fill="none" stroke={c} strokeWidth="1" />
      <circle cx="110" cy="12" r="1.8" fill={c} />
    </svg>
  );
}

export function Heading({ km, en, light = false }: { km: string; en: string; light?: boolean }) {
  return (
    <header className="mb-8">
      <h2 className={`font-display km-title text-xl sm:text-2xl ${light ? "text-champagne" : "text-burgundy"}`}>{km}</h2>
      <p className={`font-latin text-lg italic ${light ? "text-champagne/80" : "text-gold"}`}>{en}</p>
      <Divider light={light} />
    </header>
  );
}

export default function Section({
  id,
  tone = "ivory",
  children,
}: {
  id: string;
  tone?: keyof typeof tones;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className={`px-5 py-16 md:py-24 ${tones[tone]}`}>
      <Reveal className="mx-auto w-full max-w-xl text-center md:max-w-2xl">{children}</Reveal>
    </section>
  );
}
