import { wedding } from "@/config/wedding";
import Section, { Heading } from "./Section";

export default function Venue() {
  const { venue } = wedding;
  return (
    <Section id="venue" tone="blush">
      <Heading km="ទីតាំង" en="Venue" />
      <div className="gold-frame bg-ivory/80 px-5 py-8">
        <p className="font-display km-title text-xl text-burgundy">{venue.khmer}</p>
        <p className="font-latin text-2xl">{venue.english}</p>
        <p className="mx-auto mt-4 max-w-xs font-latin text-lg leading-snug text-wine/90">{venue.address}</p>
        <a
          href={venue.mapUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="km mt-6 inline-flex min-h-12 items-center justify-center bg-burgundy px-8 py-2 text-base text-ivory transition hover:bg-wine"
        >
          {venue.buttonLabel}
          <span className="ml-2 font-latin text-sm italic text-champagne">{venue.buttonLabelEnglish}</span>
        </a>
      </div>
    </Section>
  );
}
