import { wedding } from "@/config/wedding";
import Section, { Heading } from "./Section";

export default function Programme() {
  return (
    <Section id="programme">
      <Heading km="កម្មវិធីពិធី" en="Programme" />
      <ol className="relative mx-auto max-w-md text-left">
        <span aria-hidden="true" className="absolute bottom-2 left-[5.25rem] top-2 w-px bg-gold/50 sm:left-[6.25rem]" />
        {wedding.programme.map((p) => (
          <li key={p.time} className="relative flex gap-5 pb-8 last:pb-0">
            <time className="w-16 shrink-0 pt-1 text-right font-latin text-base font-semibold leading-tight text-gold sm:w-20 sm:text-lg">
              {p.time.split(" – ").map((t, i, a) => (
                <span key={t} className="block">
                  {t}
                  {i < a.length - 1 ? " –" : ""}
                </span>
              ))}
            </time>
            <span aria-hidden="true" className="absolute left-[4.85rem] top-[0.9rem] h-2.5 w-2.5 rotate-45 bg-gold sm:left-[5.85rem]" />
            <p className="km pl-4 text-base sm:text-lg">{p.khmer}</p>
          </li>
        ))}
      </ol>
    </Section>
  );
}
