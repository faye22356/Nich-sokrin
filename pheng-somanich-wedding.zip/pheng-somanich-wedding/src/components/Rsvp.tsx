"use client";
import { useState } from "react";
import { wedding } from "@/config/wedding";
import Section, { Heading } from "./Section";

type Status = "idle" | "sending" | "done" | "error";

const field =
  "w-full border border-gold/70 bg-ivory px-3 py-3 text-base text-wine placeholder:text-wine/40 disabled:opacity-60";

export default function Rsvp({ configured }: { configured: boolean }) {
  const [status, setStatus] = useState<Status>("idle");
  const [attending, setAttending] = useState<"yes" | "no">("yes");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!configured) return;
    const data = Object.fromEntries(new FormData(e.currentTarget));
    setStatus("sending");
    try {
      const res = await fetch("/api/rsvp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      setStatus(res.ok ? "done" : "error");
    } catch {
      setStatus("error");
    }
  }

  return (
    <Section id="rsvp" tone="wine">
      <Heading km="ឆ្លើយតបចូលរួម" en="RSVP" light />
      {status === "done" ? (
        <div role="status">
          <p className="km text-lg">យើងខ្ញុំបានទទួលការឆ្លើយតបរបស់អ្នក។ សូមអរគុណ!</p>
          <p className="font-latin text-xl italic text-champagne">Your reply has been received. Thank you!</p>
        </div>
      ) : (
        <form onSubmit={onSubmit} className="mx-auto max-w-md space-y-5 text-left">
          {!configured && (
            <p role="note" className="border border-champagne/60 px-4 py-3 text-center">
              <span className="km block text-sm">ការឆ្លើយតបតាមអនឡាញនឹងបើកដំណើរការឆាប់ៗនេះ។</span>
              <span className="font-latin italic text-champagne">Online replies will open soon.</span>
            </p>
          )}
          <fieldset disabled={!configured || status === "sending"} className="space-y-5">
            <div>
              <label htmlFor="name" className="km block text-sm">ឈ្មោះ <span className="font-latin italic text-champagne/80">Name</span></label>
              <input id="name" name="name" required maxLength={100} autoComplete="name" className={field} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              {([["yes", "ចូលរួម", "Joyfully attend"], ["no", "មិនអាចចូលរួម", "Regretfully decline"]] as const).map(([v, km, en]) => (
                <label key={v} className="flex cursor-pointer flex-col items-center border border-gold/70 px-2 py-3 text-center has-[:checked]:bg-gold/25">
                  <input type="radio" name="attending" value={v} checked={attending === v} onChange={() => setAttending(v)} className="sr-only" />
                  <span className="km text-sm">{km}</span>
                  <span className="font-latin text-sm italic text-champagne/80">{en}</span>
                </label>
              ))}
            </div>
            {attending === "yes" && (
              <div>
                <label htmlFor="guests" className="km block text-sm">ចំនួនភ្ញៀវ <span className="font-latin italic text-champagne/80">Number of guests</span></label>
                <select id="guests" name="guests" defaultValue="1" className={field}>
                  {Array.from({ length: wedding.rsvp.maxGuests }, (_, i) => i + 1).map((n) => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label htmlFor="message" className="km block text-sm">សារជូនពរ <span className="font-latin italic text-champagne/80">Message (optional)</span></label>
              <textarea id="message" name="message" rows={3} maxLength={500} className={field} />
            </div>
            {/* Spam trap: hidden from people */}
            <input name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" className="hidden" />
            <button
              type="submit"
              className="km min-h-12 w-full bg-gold px-6 py-3 text-base text-burgundy transition hover:bg-champagne disabled:cursor-not-allowed disabled:opacity-50"
            >
              {status === "sending" ? "កំពុងផ្ញើ…" : "ផ្ញើការឆ្លើយតប"}
              <span className="ml-2 font-latin text-sm italic">{status === "sending" ? "Sending…" : "Send reply"}</span>
            </button>
          </fieldset>
          {status === "error" && (
            <p role="alert" className="text-center">
              <span className="km block text-sm">មិនអាចផ្ញើបានទេ សូមព្យាយាមម្តងទៀត។</span>
              <span className="font-latin italic text-champagne">Your reply was not sent. Please try again.</span>
            </p>
          )}
        </form>
      )}
    </Section>
  );
}
