import { wedding } from "@/config/wedding";
import Section, { Heading } from "./Section";

type Parent = { khmer: string; english: string };

function Side({ km, en, parents, name }: { km: string; en: string; parents: Parent[]; name: Parent }) {
  return (
    <div className="gold-frame bg-ivory/80 px-4 py-7">
      <p className="km text-sm text-gold">{km}</p>
      <p className="font-latin italic text-gold">{en}</p>
      <div className="my-4 h-px w-10 mx-auto bg-gold/50" />
      <ul className="space-y-3">
        {parents.map((p) => (
          <li key={p.english}>
            <span className="km block text-base">{p.khmer}</span>
            <span className="font-latin text-lg">{p.english}</span>
          </li>
        ))}
      </ul>
      <p className="mt-5 km text-xs text-wine/70">{name.khmer}</p>
      <p className="font-latin text-sm text-wine/70">{name.english}</p>
    </div>
  );
}

export default function Family() {
  const { families, couple } = wedding;
  return (
    <Section id="family" tone="blush">
      <Heading km="គ្រួសារទាំងសងខាង" en="The two families" />
      <div className="grid gap-5 sm:grid-cols-2">
        <Side km="ខាងកូនកំលោះ" en="Groom’s family" parents={families.groom.parents} name={couple.groom} />
        <Side km="ខាងកូនក្រមុំ" en="Bride’s family" parents={families.bride.parents} name={couple.bride} />
      </div>
    </Section>
  );
}
