import { wedding } from "@/config/wedding";
import Section, { Heading } from "./Section";

export default function Gallery() {
  const photos = wedding.gallery;
  return (
    <Section id="gallery">
      <Heading km="រូបភាព" en="Gallery" />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {photos.length > 0
          ? photos.map((p) => (
              <div key={p.src} className="gold-frame aspect-[4/5] overflow-hidden bg-blush/40 p-1.5">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={p.src} alt={p.alt} loading="lazy" decoding="async" className="h-full w-full object-cover" />
              </div>
            ))
          : Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                aria-hidden="true"
                className="gold-frame flex aspect-[4/5] items-center justify-center bg-gradient-to-br from-blush/70 to-champagne/50"
              >
                <span className="font-latin text-sm italic text-gold">Photo</span>
              </div>
            ))}
      </div>
    </Section>
  );
}
