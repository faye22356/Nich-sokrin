"use client";
import { useEffect, useState } from "react";
import { wedding } from "@/config/wedding";
import Section, { Heading } from "./Section";

const start = Date.parse(wedding.date.startIso);
const end = Date.parse(wedding.date.endIso);

const units = [
  { key: "d", km: "ថ្ងៃ", en: "days" },
  { key: "h", km: "ម៉ោង", en: "hours" },
  { key: "m", km: "នាទី", en: "minutes" },
  { key: "s", km: "វិនាទី", en: "seconds" },
] as const;

export default function Countdown() {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    setNow(Date.now());
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  let content: React.ReactNode;
  if (now !== null && now >= end) {
    content = (
      <>
        <p className="km text-lg">សូមអរគុណដែលបានចូលរួមអបអរសាទរជាមួយយើងខ្ញុំ។</p>
        <p className="font-latin text-xl italic text-champagne">Thank you for celebrating with us.</p>
      </>
    );
  } else if (now !== null && now >= start) {
    content = (
      <>
        <p className="font-display km-title text-xl text-champagne">ថ្ងៃនេះគឺជាថ្ងៃមង្គលការ</p>
        <p className="font-latin text-2xl italic">Today is the day.</p>
      </>
    );
  } else {
    const total = now === null ? null : Math.max(0, Math.floor((start - now) / 1000));
    const v =
      total === null
        ? null
        : { d: Math.floor(total / 86400), h: Math.floor((total % 86400) / 3600), m: Math.floor((total % 3600) / 60), s: total % 60 };
    content = (
      <div className="grid grid-cols-4 gap-2 sm:gap-4" role="timer" aria-label="Countdown to the wedding">
        {units.map((u) => (
          <div key={u.key} className="border border-gold/70 px-1 py-4">
            <div className="font-latin text-3xl font-medium tabular-nums text-champagne sm:text-5xl">
              {v ? String(v[u.key]).padStart(2, "0") : "--"}
            </div>
            <div className="km text-xs sm:text-sm">{u.km}</div>
            <div className="font-latin text-xs italic text-champagne/70">{u.en}</div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <Section id="countdown" tone="wine">
      <Heading km="រាប់ថយក្រោយ" en="Counting down" light />
      {content}
      <p className="mt-6 font-latin text-sm italic text-champagne/70">{wedding.date.english} · Phnom Penh</p>
    </Section>
  );
}
