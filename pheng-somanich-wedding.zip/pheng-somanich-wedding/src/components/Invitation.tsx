import { wedding } from "@/config/wedding";
import Section, { Heading } from "./Section";

export default function Invitation() {
  const { invitation, couple, date } = wedding;
  return (
    <Section id="invitation">
      <Heading km={invitation.heading.khmer} en={invitation.heading.english} />
      <div className="space-y-4">
        {invitation.khmer.map((t) => (
          <p key={t} className="km text-base sm:text-lg">{t}</p>
        ))}
      </div>
      <div className="mx-auto my-8 h-px w-16 bg-gold/60" />
      <div className="space-y-3 font-latin text-lg leading-relaxed text-wine/90 sm:text-xl">
        {invitation.english.map((t) => (
          <p key={t}>{t}</p>
        ))}
      </div>
      <div className="gold-frame mx-auto mt-10 max-w-sm bg-ivory/70 px-4 py-6">
        <p className="font-display km-title text-base text-burgundy">
          {couple.groom.khmer} <span className="text-gold">&amp;</span> {couple.bride.khmer}
        </p>
        <p className="km mt-2 text-sm">{date.khmer}</p>
        <p className="km text-sm text-wine/90">{date.khmerLunar}</p>
        <p className="mt-1 font-latin text-lg italic text-gold">{date.english}</p>
      </div>
    </Section>
  );
}
