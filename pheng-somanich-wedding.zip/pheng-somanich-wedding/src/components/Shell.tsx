"use client";
import { useEffect, useRef, useState } from "react";
import { wedding } from "@/config/wedding";

type Stage = "closed" | "opening" | "open";

const nav = [
  { id: "invitation", km: "អញ្ជើញ", en: "Invitation" },
  { id: "programme", km: "កម្មវិធី", en: "Programme" },
  { id: "venue", km: "ទីតាំង", en: "Venue" },
  { id: "gallery", km: "រូបភាព", en: "Gallery" },
  { id: "rsvp", km: "ឆ្លើយតប", en: "RSVP" },
];

export default function Shell({ children }: { children: React.ReactNode }) {
  const [stage, setStage] = useState<Stage>("closed");
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const { couple, date, music } = wedding;
  const hasMusic = Boolean(music.src);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  useEffect(() => {
    document.documentElement.style.overflow = stage === "open" ? "" : "hidden";
    return () => {
      document.documentElement.style.overflow = "";
    };
  }, [stage]);

  function openInvitation() {
    setStage("opening");
    // Music only starts here, after the guest has tapped - never automatically.
    if (hasMusic && audioRef.current) {
      audioRef.current.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    }
    window.setTimeout(() => setStage("open"), 1900);
  }

  function togglePlay() {
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) a.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    else {
      a.pause();
      setPlaying(false);
    }
  }
  function toggleMute() {
    const a = audioRef.current;
    if (!a) return;
    a.muted = !a.muted;
    setMuted(a.muted);
  }

  const ctl =
    "flex h-11 w-11 items-center justify-center rounded-full border border-gold bg-burgundy/90 text-champagne backdrop-blur transition hover:bg-wine";

  return (
    <>
      {children}

      {hasMusic && (
        <audio ref={audioRef} src={music.src} loop preload="none">
          Your browser does not support audio.
        </audio>
      )}

      {stage !== "closed" && stage !== "opening" && hasMusic && (
        <div className="fixed right-3 top-3 z-40 flex gap-2">
          <button type="button" onClick={togglePlay} className={ctl} aria-label={playing ? "Pause music" : "Play music"}>
            {playing ? (
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor"><path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" /></svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor"><path d="M8 5l11 7-11 7z" /></svg>
            )}
          </button>
          <button type="button" onClick={toggleMute} className={ctl} aria-label={muted ? "Unmute music" : "Mute music"} aria-pressed={muted}>
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z" fill="currentColor" />
              {muted ? <path d="M16 9.5l5 5M21 9.5l-5 5" /> : <path d="M16 9a4 4 0 010 6M18.5 6.5a8 8 0 010 11" />}
            </svg>
          </button>
        </div>
      )}

      {stage === "open" && (
        <nav aria-label="Sections" className="fixed bottom-3 left-1/2 z-40 w-[calc(100%-1.5rem)] max-w-md -translate-x-1/2 border border-gold bg-burgundy/95 backdrop-blur">
          <ul className="flex justify-between">
            {nav.map((n) => (
              <li key={n.id} className="flex-1">
                <a href={`#${n.id}`} className="block px-1 py-2 text-center text-champagne hover:bg-wine">
                  <span className="km block text-[11px] leading-snug sm:text-xs">{n.km}</span>
                  <span className="block font-latin text-[11px] italic leading-none text-champagne/70">{n.en}</span>
                </a>
              </li>
            ))}
          </ul>
        </nav>
      )}

      {stage !== "open" && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Wedding invitation cover"
          className={`fixed inset-0 z-50 overflow-hidden text-ivory ${stage === "opening" ? "cover-opening" : ""}`}
        >
          <div className="cover-panel cover-left absolute inset-y-0 left-0 w-1/2 bg-burgundy">
            <div className="absolute inset-3 border border-gold/70 border-r-0" />
          </div>
          <div className="cover-panel cover-right absolute inset-y-0 right-0 w-1/2 bg-burgundy">
            <div className="absolute inset-3 border border-gold/70 border-l-0" />
          </div>

          <div className="cover-content absolute inset-0 flex flex-col items-center justify-center overflow-y-auto px-6 py-10 text-center">
            <div
              aria-hidden="true"
              className="mb-6 flex h-24 w-24 items-center justify-center rounded-full border border-gold bg-wine shadow-[0_0_0_5px_#5A0F22,0_0_0_6px_rgba(184,137,58,0.7)]"
            >
              <span className="font-display text-3xl leading-none text-champagne">
                {couple.monogram[0]}
                <span className="mx-0.5 text-gold">·</span>
                {couple.monogram[1]}
              </span>
            </div>
            <h1 className="max-w-full">
              <span className="font-display km-title block text-xl text-champagne sm:text-3xl">{couple.groom.khmer}</span>
              <span className="font-latin text-2xl italic text-gold sm:text-3xl">&amp;</span>
              <span className="font-display km-title block text-xl text-champagne sm:text-3xl">{couple.bride.khmer}</span>
              <span className="mt-3 block font-latin text-2xl tracking-wide sm:text-3xl">
                {couple.groom.english} &amp; {couple.bride.english}
              </span>
            </h1>
            <div className="my-5 h-px w-24 bg-gold/70" />
            <p className="km text-base sm:text-lg">{date.khmer}</p>
            <p className="font-latin text-lg italic text-champagne">{date.english}</p>
            <button
              type="button"
              onClick={openInvitation}
              className="cover-hint km mt-9 min-h-12 border border-gold bg-gold/15 px-8 py-2 text-base text-champagne transition hover:bg-gold/30"
            >
              បើកការអញ្ជើញ
              <span className="ml-2 font-latin text-sm italic">Open invitation</span>
            </button>
          </div>
        </div>
      )}
    </>
  );
}
