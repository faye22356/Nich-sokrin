import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        burgundy: "#5A0F22",
        wine: "#7A1630",
        gold: "#B8893A",
        champagne: "#E6D0A1",
        ivory: "#FBF5E9",
        blush: "#F0D5D1",
      },
      fontFamily: {
        // Latin letters use Cormorant; Khmer letters automatically fall back to Noto Serif Khmer.
        body: ["var(--font-latin)", "var(--font-khmer)", "serif"],
        display: ["var(--font-moul)", "var(--font-latin)", "serif"],
        latin: ["var(--font-latin)", "serif"],
      },
    },
  },
  plugins: [],
};
export default config;
