# Pheng & Somanich Wedding Invitation

Khmer + English wedding invitation website (Next.js, TypeScript, Tailwind CSS).
Wedding: Sunday, 7 March 2027 · Mealea Restaurant, Phnom Penh.

**Status: unpublished draft.** Read `PRIVATE_CHECKLIST.md` first: it lists what still needs confirming.
Keep this GitHub repository **Private**.

## Where to edit things

| What | File |
|---|---|
| Names, parents, dates, programme, venue, map link, music, photos list, invitation & closing text | `src/config/wedding.ts` |
| Photos | put files in `public/gallery/`, then list them in `wedding.gallery` |
| Music | put file in `public/audio/`, set `music.src` (e.g. `"/audio/song.mp3"`) |
| Colours | `tailwind.config.ts` |
| Small labels (RSVP form, navigation, countdown) | `src/components/*.tsx` |
| RSVP destination | environment variable `RSVP_WEBHOOK_URL` (see `.env.example`) |

Ceremony names are Khmer only. Do not add English to `programme`.
In `wedding.ts`, only change text inside the quotation marks.

## Project structure
```
src/config/wedding.ts      all editable content
src/app/layout.tsx         fonts, page title, sharing preview, search-engine setting
src/app/page.tsx           order of sections
src/app/globals.css        textures, cover animation
src/app/api/rsvp/route.ts  sends RSVP answers to your destination
src/components/            Shell (cover, music, menu), Invitation, Family, Countdown,
                           Programme, Venue, Gallery, Rsvp, Closing
public/gallery, public/audio   your photos and music
```

## RSVP setup (free option)
1. Create a free form at formspree.io (or another service that accepts JSON posts).
2. Copy its endpoint URL.
3. In Vercel: Project → Settings → Environment Variables → add `RSVP_WEBHOOK_URL`, then redeploy.
4. Submit a test reply and confirm it reaches you. Until then the form stays closed and says replies will open soon.
Collected: name, attending yes/no, guest count, optional message.

## GitHub (do this first)
1. github.com → **New repository** → name `pheng-somanich-wedding` → **Private** → Create.
2. Unzip the project on your computer. In the new repository choose **uploading an existing file**, drag in the *contents* of the folder (folders included, not the zip), then **Commit changes**.
   (`.env` files and `node_modules` must never be uploaded; `.gitignore` already excludes them.)
3. **Edit a file:** open it → pencil icon → change text → **Commit changes** with a clear message such as "Update ceremony time".
4. **Review changes:** the commit page shows red (removed) and green (added) lines.
5. **Go back:** repository → **History** (or a file's History) → open an older commit → view or copy the old text.
6. **Test locally (optional):** install Node.js 18.18 or newer, then in the project folder run `npm install`, then `npm run dev`, and open http://localhost:3000. Run `npm run build` to check for errors.
Editing this README or a prompt does not change the website; only the source files do. After Vercel is connected, each commit redeploys automatically.

## Vercel (only after you approve everything)
1. Finish `PRIVATE_CHECKLIST.md` and run `npm run build` (or review Vercel's preview build).
2. vercel.com → **Add New → Project** → **Import** the GitHub repository (allow access to this repo only).
3. Framework is detected as **Next.js**; keep the defaults (build `next build`).
4. Add environment variables (`RSVP_WEBHOOK_URL`, optionally `NEXT_PUBLIC_SITE_URL`) before the first deploy.
5. Click **Deploy** only when you are ready; test the link on your phone; add a custom domain later if wanted.
To keep the draft from going live, don't import it into Vercel yet.
