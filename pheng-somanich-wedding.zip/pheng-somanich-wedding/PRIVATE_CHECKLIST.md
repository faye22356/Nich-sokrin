# Private development checklist (delete or keep this repo PRIVATE)

Nothing below has been confirmed by the couple unless it says so. Do not publish until every box is ticked.

## Must confirm before launch
- [ ] **Khmer lunar date** – `ថ្ងៃអាទិត្យ ១៤ រោច ខែផល្គុន ឆ្នាំមមី អដ្ឋស័ក ព.ស. ២៥៧០` was supplied by the couple and is shown as supplied. It has NOT been checked against a Cambodian calendar. (`wedding.ts` → `date.khmerLunar`; set `khmerLunarVerified: true` after checking.)
- [ ] **10:00 ceremony name** – supplied wording was `ពិធីសែនគួចចងដែ`; the site uses `ពិធីសែនគួចចងដៃ` ("ដៃ"). Ask the family which spelling/name is correct. (`wedding.ts` → `programme`)
- [ ] **Other programme wording** – ask the family to read every Khmer programme line once.
- [ ] **Venue map pin** – no exact Google Maps link was supplied. The button currently opens a Google Maps *search* for "Mealea Restaurant, No. 44 Sothearos Boulevard…". Open it, confirm it is the right place, then paste the venue's own share link into `venue.mapUrl`.
- [ ] **Songs** – no song title, link or audio file was available to me, so no music is configured and the player is hidden. Add the audio file to `public/audio/` and set `music.src`, `title`, `artist`, `sourceNote`. You must have permission to use the song. YouTube/Spotify page links cannot be played directly.
- [ ] **Photos** – no real photos were available. The gallery shows blank "Photo" frames. Add images to `public/gallery/` (about 1600px wide, JPG, under 400 KB each) and list them in `wedding.gallery`.
- [ ] **RSVP destination** – none configured. The form is closed and tells guests "online replies will open soon". Create a destination (e.g. a free Formspree form), set `RSVP_WEBHOOK_URL`, redeploy, then send yourself a test reply and confirm it arrives.
- [ ] **Invitation & closing wording** – the Khmer and English text in `wedding.ts` is my draft. Have a fluent Khmer reader and the families approve it. Also check all small Khmer button/label text in `src/components/*.tsx` (RSVP form, navigation, countdown).
- [ ] **Khmer Gregorian date line** – `ថ្ងៃអាទិត្យ ទី៧ ខែមីនា ឆ្នាំ២០២៧` – confirm style.
- [ ] **Social-sharing image** – none added yet. Optionally add `public/og.jpg` (1200×630) and reference it in `src/app/layout.tsx`.
- [ ] **Search-engine visibility** – the site asks search engines NOT to list it (`robots` in `layout.tsx`). Keep for a guests-only invitation.

## Not yet verified (by me)
- `npm install`, `npm run build`, type-checking and browser testing have NOT been run (no internet in my environment). Run them yourself or let Vercel's preview build report errors.
- Layout on real iPhone/Android/tablet/desktop has not been viewed.
- Khmer font rendering (Noto Serif Khmer, Moul via Google Fonts) must be checked on your phone.
